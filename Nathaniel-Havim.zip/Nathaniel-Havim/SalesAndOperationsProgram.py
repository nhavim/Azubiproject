#Nathaniel Havim
#nathaniel.havim@azubiafrica.org
'''
- An initial stock level for a product 

- The number of month(s) to plan 

- The planned sales quantity for each month

Based on this data, calculate the required production quantity as follows:

- If the sales quantity is smaller than the stock level of the previous month, the
production quantity is 0

- If the sales quantity is larger than the stock level of the previous month, the
production quantity is this differece
'''
# Ask user to enter the initial stock level, cast to integer and save as initial_stock_level
initial_stock_level = int(input("Please enter the initial stock level: "))

# Ask user to enter the number of months to plan), cast to integer and save as no_of_months
no_of_months = int(input("Plese enter the of months to plan: "))

# Ask user to enter the planned sale quantity), cast to integer and save as planned_sale_quantity
#planned_sale_quantity = int(input("Plese enter the planned sale quantity: "))

# Set an Accumulator for the dictionary of monthly sales
monthly_sales = {}

# For each month, ask user to enter the planned sale quatity
# To do this loop through the month using a range
for month in range(1, no_of_months+1):
#   Ask user to enter the planned sale quantity for the month, cast to integer and save as planned_sale_quantity
    planned_sale_quantity = int(input(f"Please enter the planned sale quantity {month}: "))
#   Add the planned sale quantity to the dictionary of monthly sales
    monthly_sales[month] = planned_sale_quantity


# Loop through the dictionary of monthly sales:
for month, planned_sale_quantity in monthly_sales.items():
#       Check if planned_sale_quantity > Initial Stock
    if initial_stock_level > planned_sale_quantity: 
          print(f"Production Quantity for month {month} is 0")
#         Reduce the stock level by the production Amount
          initial_stock_level -= planned_sale_quantity

#      Else:
    else:
#        How much do you have to produce for this month?
        quantity_produced = planned_sale_quantity - initial_stock_level
#        Print the Production Quantity
        print(f"Production Quantity for Month {month} is {quantity_produced}")
#        Update the stock level
        initial_stock_level += quantity_produced - planned_sale_quantity
